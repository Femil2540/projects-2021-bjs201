# Inaugural project

**Results:**
The finding of the project can be seen from running [inauguralproject.ipynb](inauguralproject.ipynb). The key takeaways from the assignment are summarized under the Conclusion, while the code and the steps taken to get to the solution, are demonstrated accordingly to the structure of the assignment

**Dependencies:** 
Apart from a standard Anaconda Python 3 installation, the project requires no further packages.

**Disclaimer:** 
The code of the project is the main concern of this paper, as the economic model is compareable with what we have seen in previous courses. I have spent a great amount of time on ensuring the loops from assignment 3 and onwards, but with little luck and alternative solutions that have not been directly vetted, but only guided by the course coordinator. Hence, I really look forward to getting feedback and learning the perhaps more intuitive way to engage in such a problem and ultimately get better at writing code and solving problems in this setting. 

Thanks for your time and consideration :) 
